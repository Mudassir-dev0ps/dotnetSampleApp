# Week 1 — Sample Applications

Runnable companions to the Week 1 hands-on labs. All target **.NET 8**
(the current LTS) — retarget the `<TargetFramework>` in each `.csproj`
to `net9.0` if you'd rather match whatever SDK Visual Studio 2026
installs by default, then let VS restore/rebuild.

| Folder | Used in | Open with |
|---|---|---|
| `Day3-HealthCheckApp/` | Day 3 lab — deploy & validate on IIS | `Day3.SampleApp.sln` |
| `Day1-OrderFlow/` | Day 1 lab — dependency mapping | `OrderFlow.sln` |
| `Day2-ShopEasy/` | Day 2 lab — dependency mapping | `ShopEasy.sln` |
| `IIS-Setup-Walkthrough.docx` | Day 3 lab | Word |

Each subfolder has its own `README.md` with run instructions,
what-to-try steps, and how it maps back to that day's lab document.

## First-time setup on the VM

1. Confirm the .NET SDK is present (Visual Studio 2026 installs it):
   ```
   dotnet --version
   ```
2. For IIS deployment (Day 3), follow `IIS-Setup-Walkthrough.docx` first
   — it covers enabling the IIS role and installing the ASP.NET Core
   Hosting Bundle, both one-time VM setup steps.

## Quick start — recommended order

1. **Day 1:** open `Day1-OrderFlow\OrderFlow.sln`, run both projects
   (multiple startup projects), browse `http://localhost:5080`.
2. **Day 2:** open `Day2-ShopEasy\ShopEasy.sln`, run all three projects,
   browse `http://localhost:5090/api/products`.
3. **Day 3:** open `Day3-HealthCheckApp\Day3.SampleApp.sln`, run it with
   F5 first to confirm it works, then follow the IIS walkthrough to
   publish and host it under IIS for the full lab.

## Port map (so nothing collides if run together)

| App | Port |
|---|---|
| OrderFlow.Web | 5080 |
| OrderFlow.API | 5081 |
| ShopEasy.API | 5090 |
| Catalog.Service | 5091 |
| Pricing.Service | 5092 |
| Day3.SampleApp | 5000 (Kestrel default; becomes whatever IIS binding you assign once deployed) |

## Note on these samples

These were generated to closely match each day's `Hands-On-Lab.docx`
scenario, but were **not compiled/tested on a machine with the .NET SDK
installed** (this authoring environment doesn't have one). The code
uses standard, well-established ASP.NET Core minimal-API patterns, but
please do a build on the VM before your first class session, in case a
small fix is needed:

```
dotnet build Day1-OrderFlow\OrderFlow.sln
dotnet build Day2-ShopEasy\ShopEasy.sln
dotnet build Day3-HealthCheckApp\Day3.SampleApp.sln
```
