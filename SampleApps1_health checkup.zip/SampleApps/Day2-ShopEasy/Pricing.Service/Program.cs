// Pricing Microservice — represents the "Pricing Microservice" from the
// Day 2 hands-on lab scenario (ShopEasy). Owns dynamic pricing logic,
// deployed and scaled independently of the Catalog Microservice.

var app = WebApplication.CreateBuilder(args).Build();

var prices = new Dictionary<int, decimal>
{
    [1] = 19.99m,
    [2] = 89.99m,
    [3] = 34.50m,
};

app.MapGet("/api/pricing/{productId:int}", (int productId) =>
    prices.TryGetValue(productId, out var price)
        ? Results.Ok(new { productId, price })
        : Results.NotFound());

app.MapGet("/health", () => Results.Ok(new { status = "Healthy", service = "Pricing.Service" }));

app.Run("http://localhost:5092");
