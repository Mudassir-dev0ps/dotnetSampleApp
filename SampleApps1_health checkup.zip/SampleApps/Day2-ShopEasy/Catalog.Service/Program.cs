// Catalog Microservice — represents the "Catalog Microservice" from the
// Day 2 hands-on lab scenario (ShopEasy). Owns its own product data.
//
// In the real scenario this sits behind a Redis distributed cache to
// reduce database load (see Day 2 trainer notes, section 7 — Caching).
// That cache is simulated here as a simple static dictionary with a
// comment, rather than a real Redis instance, to keep the sample
// runnable without extra infrastructure.

var app = WebApplication.CreateBuilder(args).Build();

var catalog = new[]
{
    new { Id = 1, Name = "Wireless Mouse" },
    new { Id = 2, Name = "Mechanical Keyboard" },
    new { Id = 3, Name = "USB-C Hub" },
};

// Simulated cache layer. A real deployment would check Redis first,
// then fall back to the product database on a cache miss.
app.MapGet("/api/catalog", () => Results.Ok(catalog));

app.MapGet("/health", () => Results.Ok(new { status = "Healthy", service = "Catalog.Service" }));

app.Run("http://localhost:5091");
