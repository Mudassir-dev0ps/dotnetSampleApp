# Day 2 Sample App — ShopEasy

A minimal, runnable slice of the **ShopEasy** scenario from
`Day2-Hands-On-Lab.docx` ("Build an Application Dependency Map"),
demonstrating a microservices fan-out call pattern.

| Component (this sample) | Maps to lab scenario component | Port |
|---|---|---|
| `ShopEasy.API` | ShopEasy.API (Business Logic / API tier) | 5090 |
| `Catalog.Service` | Catalog Microservice | 5091 |
| `Pricing.Service` | Pricing Microservice | 5092 |

`ShopEasy.API` calls both microservices **synchronously** and combines
their results — this is the "ShopEasy.API → Catalog Microservice" and
"ShopEasy.API → Pricing Microservice" rows in the lab's dependency table.

The remaining components from the full scenario (RabbitMQ, Fulfillment
Service, Warehouse System, Redis, Azure AD) are **not** implemented —
they're intended to stay a paper/whiteboard exercise. This runnable
slice exists to give students a concrete example of a **hard** vs.
**soft** dependency within the same endpoint (see comments in
`ShopEasy.API/Program.cs`): Catalog failing fails the whole request;
Pricing failing degrades gracefully per-product instead.

## Run it

### Option A — Visual Studio 2026 (recommended)

1. Open `ShopEasy.sln`.
2. Right-click the **Solution** in Solution Explorer → **Set Startup Projects...**
3. Choose **Multiple startup projects**, set `Catalog.Service`,
   `Pricing.Service`, and `ShopEasy.API` all to **Start** (order doesn't
   matter — each retries its HTTP calls if a dependency isn't up yet on
   the very first request, just refresh once).
4. Press **F5**. All three launch together; `ShopEasy.API`'s browser
   window opens automatically at `/api/products`.

### Option B — command line

Open **three terminals**:

```
# Terminal 1
cd Catalog.Service
dotnet run

# Terminal 2
cd Pricing.Service
dotnet run

# Terminal 3
cd ShopEasy.API
dotnet run
```

Browse to **http://localhost:5090/api/products** — you should see a
JSON array combining catalog items with their prices.

## Demonstrate hard vs. soft dependency behavior

- **Soft dependency:** stop `Pricing.Service`, refresh
  `/api/products` — the response still returns, but each product shows
  `"price": null, "priceUnavailable": true` instead of failing outright.
- **Hard dependency:** restart `Pricing.Service`, then stop
  `Catalog.Service` instead, and refresh `/api/products` — the whole
  request now fails with an HTTP 502, because `ShopEasy.API` cannot
  build a product list at all without the Catalog Microservice.

Use this to anchor the lab's discussion question about Redis caching
in front of Catalog, and why splitting Pricing into its own service
makes operational sense even though it adds a network call.
