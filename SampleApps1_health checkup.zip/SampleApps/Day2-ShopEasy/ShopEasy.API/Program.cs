// ShopEasy.API — represents the "ShopEasy.API" component from the
// Day 2 hands-on lab scenario. Calls two independently deployed
// microservices SYNCHRONOUSLY over REST and combines their results —
// illustrating the "Business Logic / API tier" fanning out to
// microservices (see Day 2 trainer notes, sections 3 and 10).
using System.Net.Http.Json;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("Catalog", client =>
{
    var baseUrl = builder.Configuration["Catalog:BaseUrl"] ?? "http://localhost:5091";
    client.BaseAddress = new Uri(baseUrl);
    client.Timeout = TimeSpan.FromSeconds(5);
});

builder.Services.AddHttpClient("Pricing", client =>
{
    var baseUrl = builder.Configuration["Pricing:BaseUrl"] ?? "http://localhost:5092";
    client.BaseAddress = new Uri(baseUrl);
    client.Timeout = TimeSpan.FromSeconds(5);
});

var app = builder.Build();

// Combines Catalog + Pricing into one response — a common API Gateway /
// Backend-for-Frontend pattern in a microservices architecture.
app.MapGet("/api/products", async (IHttpClientFactory httpClientFactory) =>
{
    var catalogClient = httpClientFactory.CreateClient("Catalog");
    var pricingClient = httpClientFactory.CreateClient("Pricing");

    List<CatalogItem> catalog;
    try
    {
        catalog = await catalogClient.GetFromJsonAsync<List<CatalogItem>>("/api/catalog") ?? new();
    }
    catch (Exception ex)
    {
        // Catalog Microservice is a HARD dependency for this endpoint —
        // if it's unreachable, we can't build a product list at all.
        return Results.Problem($"Catalog Microservice unreachable: {ex.Message}", statusCode: 502);
    }

    var products = new List<object>();
    foreach (var item in catalog)
    {
        try
        {
            var priceInfo = await pricingClient.GetFromJsonAsync<PriceDto>($"/api/pricing/{item.Id}");
            products.Add(new { item.Id, item.Name, Price = priceInfo?.Price });
        }
        catch (Exception)
        {
            // Pricing Microservice failure degrades gracefully for THIS product
            // rather than failing the whole request — a SOFT dependency pattern,
            // in contrast to the hard dependency on Catalog above.
            products.Add(new { item.Id, item.Name, Price = (decimal?)null, PriceUnavailable = true });
        }
    }

    return Results.Ok(products);
});

app.MapGet("/health", () => Results.Ok(new { status = "Healthy", service = "ShopEasy.API" }));

app.Run("http://localhost:5090");

record CatalogItem(int Id, string Name);
record PriceDto(int ProductId, decimal Price);
