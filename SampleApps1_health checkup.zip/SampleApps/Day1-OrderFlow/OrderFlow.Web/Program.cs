// OrderFlow.Web — represents the "OrderFlow.Web" component from the
// Day 1 hands-on lab scenario. Calls OrderFlow.API SYNCHRONOUSLY over
// HTTP to render the order list, illustrating an internal, hard,
// synchronous dependency (see Day1-Hands-On-Lab.docx, "Worked Example").
using System.Net.Http.Json;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("OrderFlowApi", client =>
{
    var baseUrl = builder.Configuration["OrderFlowApi:BaseUrl"] ?? "http://localhost:5081";
    client.BaseAddress = new Uri(baseUrl);
    client.Timeout = TimeSpan.FromSeconds(5);
});

var app = builder.Build();

app.MapGet("/", async (IHttpClientFactory httpClientFactory) =>
{
    var client = httpClientFactory.CreateClient("OrderFlowApi");

    try
    {
        var orders = await client.GetFromJsonAsync<List<OrderDto>>("/api/orders") ?? new();

        var rows = string.Join("", orders.Select(o =>
            $"<tr><td>{o.Id}</td><td>{o.Customer}</td><td>{o.Status}</td></tr>"));

        var html = $"""
            <html>
            <head><title>OrderFlow.Web</title></head>
            <body style="font-family: Segoe UI, sans-serif; margin: 40px; max-width: 720px;">
                <h1>OrderFlow — Recent Orders</h1>
                <p>This page calls <code>OrderFlow.API</code> synchronously over HTTP
                   to render this list — an internal, <strong>hard, synchronous</strong>
                   dependency (see the Day 1 lab's dependency table).</p>
                <table border="1" cellpadding="6" cellspacing="0">
                    <tr><th>Order ID</th><th>Customer</th><th>Status</th></tr>
                    {rows}
                </table>
            </body>
            </html>
            """;

        return Results.Content(html, "text/html");
    }
    catch (Exception ex)
    {
        var html = $"""
            <html>
            <head><title>OrderFlow.Web</title></head>
            <body style="font-family: Segoe UI, sans-serif; margin: 40px; max-width: 720px;">
                <h1>OrderFlow.Web</h1>
                <p style="color:#b00020;"><strong>OrderFlow.API is unreachable:</strong> {ex.Message}</p>
                <p>This simulates what happens when a <strong>hard dependency</strong> fails —
                   compare this to the Day 1 lab discussion question about SPOFs.
                   Start <code>OrderFlow.API</code> and refresh this page to recover.</p>
            </body>
            </html>
            """;

        return Results.Content(html, "text/html", statusCode: StatusCodes.Status502BadGateway);
    }
});

app.MapGet("/health", () => Results.Ok(new { status = "Healthy", service = "OrderFlow.Web" }));

app.Run("http://localhost:5080");

record OrderDto(int Id, string Customer, string Status);
