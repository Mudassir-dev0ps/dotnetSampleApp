// OrderFlow.API — represents the "OrderFlow.API" component from the
// Day 1 hands-on lab scenario. Backs OrderFlow.Web with order data.
// In the real scenario this would query SQL Server ("OrderFlowDB");
// here it uses an in-memory list to keep the sample runnable without
// a real database.

var app = WebApplication.CreateBuilder(args).Build();

var orders = new[]
{
    new { Id = 88231, Customer = "Alice Chen",    Status = "Placed"  },
    new { Id = 88232, Customer = "Bilal Ahmed",    Status = "Placed"  },
    new { Id = 88233, Customer = "Carla Gomez",    Status = "Shipped" },
    new { Id = 88234, Customer = "David Okoye",    Status = "Placed"  },
};

app.MapGet("/api/orders", () => Results.Ok(orders));

app.MapGet("/health", () => Results.Ok(new { status = "Healthy", service = "OrderFlow.API" }));

app.Run("http://localhost:5081");
