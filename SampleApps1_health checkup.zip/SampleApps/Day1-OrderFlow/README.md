# Day 1 Sample App — OrderFlow

A minimal, runnable version of the **OrderFlow** scenario from
`Day1-Hands-On-Lab.docx` ("Identify Components and Dependencies of a
Sample Application"). It only implements two of the ten components in
the full scenario (`OrderFlow.Web` and `OrderFlow.API`) — enough to let
students *see and break* a real synchronous, internal, hard dependency,
rather than only reasoning about it on paper.

| Component (this sample) | Maps to lab scenario component | Port |
|---|---|---|
| `OrderFlow.API` | OrderFlow.API (simulates querying `OrderFlowDB`) | 5081 |
| `OrderFlow.Web` | OrderFlow.Web | 5080 |

The other eight components in the full scenario (BatchService, Redis,
Payment Gateway, Shipping Partner API, Blob Storage, Active Directory,
SMTP relay, SQL Server) are intentionally **not** implemented — the lab
is designed to be completed on paper/whiteboard for those, using this
running pair as a concrete, hands-on anchor for "what does a hard,
synchronous, internal dependency actually look like".

## Run it

### Option A — Visual Studio 2026 (recommended)

1. Open `OrderFlow.sln`.
2. Right-click the **Solution** in Solution Explorer → **Set Startup Projects...**
3. Choose **Multiple startup projects**, set both `OrderFlow.API` and
   `OrderFlow.Web` to **Start**, with `OrderFlow.API` listed first.
4. Press **F5**. Both projects launch together; `OrderFlow.Web`'s browser
   window opens automatically at `http://localhost:5080`.

### Option B — command line

Open **two terminals** on the VM:

```
# Terminal 1
cd OrderFlow.API
dotnet run

# Terminal 2
cd OrderFlow.Web
dotnet run
```

Browse to **http://localhost:5080** — you should see a table of orders
rendered by `OrderFlow.Web`, fetched live from `OrderFlow.API`.

## Demonstrate a hard dependency failing

1. With both running, confirm the order table loads at `http://localhost:5080`.
2. Stop `OrderFlow.API` (Ctrl+C in its terminal).
3. Refresh `http://localhost:5080` — you'll see the "OrderFlow.API is
   unreachable" message instead of the order table.
4. This is exactly what the Day 1 lab means by a **hard dependency**:
   `OrderFlow.Web` cannot function without `OrderFlow.API`.
5. Restart `OrderFlow.API` and refresh again to recover.

Use this alongside the lab's dependency table and diagram exercise.
