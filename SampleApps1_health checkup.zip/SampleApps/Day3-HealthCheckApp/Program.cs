var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Home page: displays a message sourced from EXTERNAL CONFIGURATION
// (appsettings.json / appsettings.Production.json), never hard-coded.
// See Day 3 lab, Part A.
app.MapGet("/", (IConfiguration config) =>
{
    var welcomeMessage = config["WelcomeMessage"] ?? "Welcome!";
    var environmentName = app.Environment.EnvironmentName;

    var html = $"""
        <html>
        <head><title>Day 3 Sample App</title></head>
        <body style="font-family: Segoe UI, sans-serif; margin: 40px; max-width: 640px;">
            <h1>{welcomeMessage}</h1>
            <p>Environment: <strong>{environmentName}</strong></p>
            <p>This message is read from configuration, not hard-coded in the source code.
               Compare <code>appsettings.json</code> (Development) with
               <code>appsettings.Production.json</code> (Production).</p>
            <p><a href="/health">Check /health</a></p>
        </body>
        </html>
        """;

    return Results.Content(html, "text/html");
});

// Health check endpoint: simulates checking a critical dependency (e.g., a database).
// See Day 3 lab, Part B & D, and Day 3 trainer notes, section 6 (Health Checks).
//
// Flip "SimulatedDependency:Healthy" to false in appsettings.json and restart
// the app (or app pool, once deployed to IIS) to see this flip to HTTP 503.
app.MapGet("/health", (IConfiguration config) =>
{
    var dependencyHealthy = config.GetValue<bool>("SimulatedDependency:Healthy", true);

    if (dependencyHealthy)
    {
        return Results.Ok(new { status = "Healthy" });
    }

    return Results.Json(new { status = "Unhealthy" }, statusCode: StatusCodes.Status503ServiceUnavailable);
});

app.Run();
