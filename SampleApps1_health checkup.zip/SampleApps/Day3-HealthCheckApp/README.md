# Day 3 Sample App — Health Check App

This is the starter project for the **Day 3 hands-on lab**
(`Day3-Hands-On-Lab.docx`): *Deploy and Validate a Sample Application*.

It demonstrates:
- Externalized configuration (`appsettings.json` vs `appsettings.Production.json`)
- A `/health` endpoint that simulates checking a dependency, returning HTTP 200
  when healthy and HTTP 503 when not.

## Run locally (before deploying to IIS)

**Visual Studio 2026:** open `Day3.SampleApp.sln` and press **F5** — it
launches at `http://localhost:5000` and opens your browser automatically.

**Command line:** open a terminal in this folder on the VM (which has the
.NET SDK via Visual Studio 2026) and run:

```
dotnet run
```

Note the URL Kestrel prints (e.g. `http://localhost:5000`) and browse to it,
then to `/health`.

## Try the health check flip

1. Open `appsettings.json`, set `"SimulatedDependency": { "Healthy": false }`.
2. Stop and re-run the app (`Ctrl+C`, then `dotnet run` again).
3. Browse to `/health` — it should now return HTTP 503.
4. Revert the change before deploying.

## Deploy to IIS

See **`IIS-Setup-Walkthrough.docx`** (in the parent `SampleApps` folder) for
the full step-by-step: enabling the IIS role, installing the ASP.NET Core
Hosting Bundle, publishing this project, and creating the IIS site/app pool.

Quick summary:

```
dotnet publish -c Release -o C:\inetpub\Day3SampleApp
```

Then point an IIS site/application at `C:\inetpub\Day3SampleApp`, running
under an app pool set to **No Managed Code** (the ASP.NET Core Module
handles the .NET runtime, not the classic ISAPI pipeline).

To run the app under the **Production** configuration in IIS, set the
`ASPNETCORE_ENVIRONMENT` environment variable to `Production` on the
IIS Application Pool (Advanced Settings) or in `web.config` — this is what
causes `appsettings.Production.json` to override `appsettings.json`.
